/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webdatabase;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author Student
 */
// An MySQL program inherits from the top-level container java.awt.Frame
public class MySQLGui_mouse extends Frame implements MouseListener, MouseMotionListener {

 
    private TextField tfMouseX; // to display mouse-click-x
    private TextField tfMouseY; // to display mouse-click-y
     // To display the (x, y) of the current mouse-pointer position
    private TextField tfMousePositionX;
    private TextField tfMousePositionY;


    // Constructor to setup GUI components and event handlers
    public MySQLGui_mouse() {

        JFrame frame = new JFrame();
        frame.setSize(380, 180);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
        frame.setLayout(new FlowLayout());
        // "super" Frame, which is a Container, sets its layout to FlowLayout to arrange
        // the components from left-to-right, and flow to next row from top-to-bottom.

       
        // Label (anonymous)
        frame.add(new Label("X-Click: ")); // "super" frame adds Label component

        // TextField
        tfMouseX = new TextField(10); // 10 columns
        tfMouseX.setEditable(false);  // read-only
        frame.add(tfMouseX);                // "super" frame adds TextField component

        // Label (anonymous)
        frame.add(new Label("Y-Click: ")); // "super" frame adds Label component

        // TextField
        tfMouseY = new TextField(10);
        tfMouseY.setEditable(false);  // read-only
        frame.add(tfMouseY);                // "super" frame adds TextField component

        frame.add(new Label("X-Position: "));
        tfMousePositionX = new TextField(10);
        tfMousePositionX.setEditable(false);
        frame.add(tfMousePositionX);
        frame.add(new Label("Y-Position: "));
        tfMousePositionY = new TextField(10);
        tfMousePositionY.setEditable(false);
        frame.add(tfMousePositionY);

      
        // Add Listeners
        frame.addMouseMotionListener(this);
        frame.addMouseListener(this);
        // "super" frame (source) fires the MouseEvent.
        // "super" frame adds "

        frame.setTitle("Mouse Listeners");  // "super" Frame sets its title

        // For inspecting the Container/Components objects
        // System.out.println(this);
        // System.out.println(lblCount);
        // System.out.println(tfCount);
        // System.out.println(btnCount);
        frame.setLocation(0, 260);
        frame.setVisible(true);         // "super" Frame shows

        // System.out.println(this);
        // System.out.println(lblCount);
        // System.out.println(tfCount);
        // System.out.println(btnCount);
        /* MouseEvent handlers */
        // Called back upon mouse clicked
    }

    /**
     * MouseMotionEvent handlers
     *
     * @param evt
     */
    // Called back when the mouse-pointer has been moved
    @Override
    public void mouseMoved(MouseEvent evt) {
        tfMousePositionX.setText(evt.getX() + "");
        tfMousePositionY.setText(evt.getY() + "");
    }

    // Not Used, but need to provide an empty body for compilation
    @Override
    public void mouseDragged(MouseEvent evt) {
    }

    // Not used - need to provide an empty body to compile.
    @Override
    public void mousePressed(MouseEvent evt) {
    }

    @Override
    public void mouseReleased(MouseEvent evt) {
    }

    @Override
    public void mouseEntered(MouseEvent evt) {
    }

    @Override
    public void mouseExited(MouseEvent evt) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        tfMouseX.setText(e.getX() + "");
        tfMouseY.setText(e.getY() + "");
    }
}
