/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webdatabase;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Student
 */
public class MySQLGui_results extends JFrame {

    private JTextArea taResult;  // Use Swing's JTextField instead of TextArea
    private JTextField tfResultId;  // Use Swing's JTextField instead of  TextField
    private JTextField tfResultFirst;  // Use Swing's JTextField instead of TextField
    private JTextField tfResultLast;  // Use Swing's JTextField instead of TextField
    private JButton btnSeeResult;    // Using Swing's JButton instead of Button

    private String[] strResultId = new String[100];  // Use  String
    private String[] strResultFirst = new String[100];  // Use  String
    private String[] strResultLast = new String[100];  // Use  String
    private int count =1;
    
    
    // Constructor to setup the GUI components and event handlers
    public MySQLGui_results() {
        // Retrieve the content-pane of the top-level container JFrame
        // All operations done on the content-pane
        Container cp = getContentPane();
        cp.setLayout(new GridLayout(4, 1));   // The content-pane sets its layout
        cp.add(new JLabel("MySQL Results"));

        // Add and configure Results 
        tfResultId = new JTextField("ID");
        tfResultId.setEditable(false);
        cp.add(tfResultId);

        tfResultFirst = new JTextField("First Name", 20);
        tfResultFirst.setEditable(false);
        cp.add(tfResultFirst);

        tfResultLast = new JTextField("Last Name", 20);
        tfResultLast.setEditable(false);
        cp.add(tfResultLast);

        taResult = new JTextArea("All");
        taResult.setEditable(false);
        cp.add(taResult);

        btnSeeResult = new JButton("Count");
        cp.add(btnSeeResult);

        // Allocate an anonymous instance of an anonymous inner class that
        //  implements ActionListener as ActionEvent listener
        btnSeeResult.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {

                tfResultId.setText(strResultId[count]);
                tfResultFirst.setText(strResultFirst[count]);
                tfResultLast.setText(strResultLast[count]);
                taResult.setText(strResultId[count] + ": " + strResultLast[count] + "," + strResultFirst[count] + "\n");
                count++;
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Exit program if close-window button clicked
        setTitle("Swing Counter"); // "super" JFrame sets title
        setSize(300, 100);         // "super" JFrame sets initial size
        setLocation(0, 400);
        setVisible(true);          // "super" JFrame shows
    }

    public void setResults(String[] strArry, int cnt) {

        strResultId[cnt] = strArry[0];  // Use Swing's String
        strResultFirst[cnt] = strArry[1];  // Use Swing's String
        strResultLast[cnt] = strArry[2];  // Use Swing's String

    }

}
