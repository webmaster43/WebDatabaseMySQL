/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webdatabase;

/**
 *
 * @author Tutor 101
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.sql.PreparedStatement;

public class MysqlConnect {

    // init database constants
    private static final String DATABASE_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/javabase";
    private String USERNAME = "student";
    private String PASSWORD = "";
    private static final String MAX_POOL = "250";
    private static final String USE_SSL = "true";
    // init connection object
    private Connection connection;
    // init properties object
    private Properties properties;
    private Statement myStmt;
    private ResultSet myRs;

    private String[] strId = new String[100];  // Use String
    private String[] strFirst = new String[100];  // Use String
    private String[] strLast = new String[100];  // Use String

    public MysqlConnect(String un, String pw) {
        // set username
        USERNAME = un;
        // set password 
        PASSWORD = pw;

    }

    // set results
    private void setResults(String sId, String sFirst, String sLast, int c) {
        strId[c] = sId;
        strFirst[c] = sFirst;
        strLast[c] = sLast;
    }

    // create results
    public String[] getResults(int c) {

        String[] strResults = new String[3];

        strResults[0] = strId[c];
        strResults[1] = strFirst[c];
        strResults[2] = strLast[c];
        System.out.println("Result from Connection: " + strResults[2] + ", " + strResults[1]);

        return strResults;
    }

    // create properties
    private Properties getProperties() {
        if (properties == null) {
            properties = new Properties();
            properties.setProperty("user", USERNAME);
            properties.setProperty("password", PASSWORD);
            properties.setProperty("MaxPooledStatements", MAX_POOL);
            properties.setProperty("useSSL", USE_SSL);
        }
        return properties;
    }

    // connect database
    public Connection connect() {
        if (connection == null) {
            try {

                System.out.println("Database is Opening...");
                Class.forName(DATABASE_DRIVER);
                connection = DriverManager.getConnection(DATABASE_URL, getProperties());
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }

    // disconnect database
    public void disconnect() {
        if (connection != null) {
            try {
                connection.close();
                connection = null;
                System.out.println("Database is Closed...");

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    PreparedStatement readTableViaPS(String sql) throws SQLException {

        PreparedStatement statement = connect().prepareStatement(sql);
        myRs = statement.executeQuery(sql);
        System.out.println("Reading Table Data...");
        int cnt = 0;
        while (myRs.next()) {
            //System.out.println(myRs.getString("lastName") + ", " + myRs.getString("firstName"));
            setResults(myRs.getString("cId"), myRs.getString("firstName"), myRs.getString("lastName"), cnt);
            getResults(cnt);
            cnt++;
        }

        return statement;

    }

//    public function saveRecord() {
//        if (isset($this->id)) {
//            //echo "Updating id: " . $this->id . "</br>";
//        } else {
//            //echo "Creating new item </br>";
//        }
//        return isset($this->id) ? $this->updateRecord() : $this->createRecord();
//    }
//
//    public function createRecord() {
//        global $database;
//        $cid = 0;
//        $results = 0;
//        $attributes = $this->sanitized_attributes();
//        $sql = "INSERT INTO " . static::$table_name . " (";
//        $sql .= join(", ", array_keys($attributes));
//        $sql .= ") VALUES ('";
//        $sql .= join("', '", array_values($attributes));
//        $sql .= "')";
//        //echo "create sql: " . $sql . "</br>";
//        if ($database->query($sql)) {
//            $cid = $this->id = $database->insert_id();
//            //echo "id1: " . $cid . "</br>";
//            $results = $cid;
//        } else {
//            $results = false;
//        }
//        return $results;
//    }
//
//    public function updateRecord() {
//        global $database;
//        $attributes = $this->sanitized_attributes();
//        foreach ($attributes as $key => $value) {
//            $attributes_pairs[] = "{$key}='{$value}'";
//        }
//        $sql = "UPDATE " . static::$table_name . " SET ";
//        $sql .= join(", ", $attributes_pairs);
//        $sql .= " WHERE " . static::$db_id_name . "=" . $database->escape_value($this->id);
//        //echo "Update query: " . $sql . "</br>"; 
//        $database->query($sql);
//        return ($database->affected_rows() == 1) ? true : false;
//    }
//
//    public function deleteRecord() {
//        global $database;
//        $sql = "DELETE FROM " . static::$table_name;
//        $sql .= " WHERE " . static::$db_id_name . "=" . $database->escape_value($this->id);
//        $sql .= " LIMIT 1";
//        //echo "Query: " . $sql . "</br>";
//        $database->query($sql);
//        return ($database->affected_rows() == 1) ? true : false;
//    }
//
    public void insertTable(String sql) throws SQLException {
        myStmt = connection.createStatement();
        myStmt.executeUpdate(sql);

        System.out.println("Creating Record in Table...Okay");

    }

    public void readTable(String sql) throws SQLException {
        myStmt = connection.createStatement();
        myRs = myStmt.executeQuery(sql);
        System.out.println("Reading Table Data...Okay");
        int cnt = 0;
        while (myRs.next()) {
            //System.out.println(myRs.getString("lastName") + ", " + myRs.getString("firstName"));
            setResults(myRs.getString("cId"), myRs.getString("firstName"), myRs.getString("lastName"), cnt);
            getResults(cnt);
            cnt++;
        }

    }

    public void updateTable(String sql) throws SQLException {
        myStmt = connection.createStatement();
        myStmt.executeUpdate(sql);
        System.out.println("Updating Table Data...Okay");

    }

    public void deleteTable(String sql) throws SQLException {
        myStmt = connection.createStatement();
        myStmt.execute(sql);
        System.out.println("Deleting Table Data...Okay");

    }

}
