/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webdatabase;


import javax.swing.SwingUtilities;

/**
 *
 * @author Tutor 101
 */
public class WebDatabase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        // Run the GUI construction in the Event-Dispatching thread for thread-safety
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
//                new MyGui_SwingCounter(); // Let the constructor do the job
//
//                new MySQLGui_basic();
//
//                new MySQLGui_mouse();

                new MySQLGui_advanced();
                
                
        
            }
        });
    }
}
