/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webdatabase;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author Student
 */
// An MySQL program inherits from the top-level container java.awt.Frame
public class MySQLGui_advanced extends Frame implements ActionListener, MouseListener, MouseMotionListener, KeyListener {

    private Label lblUsername;    // Declare a Label component 
    private TextField tfUsername; // Declare a TextField component 
    private Label lblPassword;    // Declare a Label component 
    private TextField tfPassword; // Declare a TextField component 
    private Button btnEnter;   // Declare a Button component
    private String username = "student";     // Counter's value
    private String password = "";     // Counter's value

    private TextField tfMouseX; // to display mouse-click-x
    private TextField tfMouseY; // to display mouse-click-y
    // To display the (x, y) of the current mouse-pointer position
    private TextField tfMousePositionX;
    private TextField tfMousePositionY;

    private TextField tfInput;  // Single-line TextField to receive tfInput key
    private TextArea taDisplay; // Multi-line TextArea to taDisplay result

    private TextField tfCount;
    private Button btnCountUp, btnCountDown, btnReset;
    private int count = 0;
    private int cntCId = 10;
    
    private String keyEnter = "";
    private int pwCnt = 0;
    
    
    // Constructor to setup GUI components and event handlers
    public MySQLGui_advanced() {

        JFrame frame = new JFrame();
        frame.setSize(378, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setLayout(new FlowLayout());
        // "super" Frame, which is a Container, sets its layout to FlowLayout to arrange
        // the components from left-to-right, and flow to next row from top-to-bottom.

        lblUsername = new Label("Username");  // construct the Label component
        frame.add(lblUsername);                    // "super" Frame container adds Label component

        tfUsername = new TextField(username, 30); // construct the TextField component with initial text
        tfUsername.setEditable(true);       // set to read-only

        frame.add(tfUsername);                     // "super" Frame container adds TextField component

        lblPassword = new Label("Password");  // construct the Label component
        frame.add(lblPassword);                    // "super" Frame container adds Label component

        tfPassword = new TextField(password, 23); // construct the TextField component with initial text
        tfPassword.setEditable(true);       // set to read-only

        frame.add(tfPassword);                     // "super" Frame container adds TextField component

        btnEnter = new Button("Enter");   // construct the Button component
        frame.add(btnEnter);                    // "super" Frame container adds Button component

        // Label (anonymous)
        frame.add(new Label("X-Click: ")); // "super" frame adds Label component

        // TextField
        tfMouseX = new TextField(10); // 10 columns
        tfMouseX.setEditable(false);  // read-only
        frame.add(tfMouseX);                // "super" frame adds TextField component

        // Label (anonymous)
        frame.add(new Label("Y-Click: ")); // "super" frame adds Label component

        // TextField
        tfMouseY = new TextField(10);
        tfMouseY.setEditable(false);  // read-only
        frame.add(tfMouseY);                // "super" frame adds TextField component

        frame.add(new Label("X-Position: "));
        tfMousePositionX = new TextField(10);
        tfMousePositionX.setEditable(false);
        frame.add(tfMousePositionX);
        frame.add(new Label("Y-Position: "));
        tfMousePositionY = new TextField(10);
        tfMousePositionY.setEditable(false);
        frame.add(tfMousePositionY);

        frame.add(new Label("Enter Text: "));
        tfInput = new TextField(30);
        frame.add(tfInput);
        taDisplay = new TextArea(5, 40); // 5 rows, 40 columns
        frame.add(taDisplay);

        // Construct Counter
        frame.add(new Label("Counter"));
        tfCount = new TextField("0", 30);
        tfCount.setEditable(false);
        frame.add(tfCount);

        // Construct Buttons
        btnCountUp = new Button("Count Up");
        frame.add(btnCountUp);
        btnCountDown = new Button("Count Down");
        frame.add(btnCountDown);
        btnReset = new Button("Reset");
        frame.add(btnReset);

        // Allocate an instance of the "named" inner class BtnListener.
        BtnListener listener = new BtnListener();
        // Use the same listener instance for all the 3 Buttons.
        btnCountUp.addActionListener(listener);
        btnCountDown.addActionListener(listener);
        btnReset.addActionListener(listener);

        // Add Listeners
        tfInput.addKeyListener(this);
        tfPassword.addKeyListener(this);
        // tfInput TextField (source) fires KeyEvent.
        // tfInput adds "this" object as a KeyEvent listener.

        frame.addMouseMotionListener(this);

        frame.addMouseListener(this);
        // "super" frame (source) fires the MouseEvent.
        // "super" frame adds "

        btnEnter.addActionListener(this);
        // "btnCount" is the source object that fires an ActionEvent when clicked.
        // The source add "this" instance as an ActionEvent listener, which provides
        //   an ActionEvent handler called actionPerformed().
        // Clicking "btnCount" invokes actionPerformed().

        frame.setTitle("MySQL Password Advanced");  // "super" Frame sets its title

        // For inspecting the Container/Components objects
        // System.out.println(this);
        // System.out.println(lblCount);
        // System.out.println(tfCount);
        // System.out.println(btnCount);
        frame.setLocation(400, 0);
        frame.setVisible(true);         // "super" Frame shows

        // System.out.println(this);
        // System.out.println(lblCount);
        // System.out.println(tfCount);
        // System.out.println(btnCount);
        /* MouseEvent handlers */
        // Called back upon mouse clicked
    }

    public String getUsername() {

        return username;
    }

    public String getPassword() {

        return password;
    }

    // ActionEvent handler - Called back upon button-click.
    @Override
    public void actionPerformed(ActionEvent evt) {
        ++count;
        tfCount.setText(count + "");
        username = tfUsername.getText(); // Convert int to String 
        // Display the counter value on the TextField tfCount
        tfUsername.setText("**********"); // Convert int to String

        password = keyEnter; // Convert int to String 
        //taDisplay.append(password + ":" + keyEnter + "\n");
       
        // Display the counter value on the TextField tfCount
        tfPassword.setText("**********"); // Convert int to String

        // !_ note _! this is just init
        // it will not create a connection
        MysqlConnect mysqlConnect = new MysqlConnect(username, password);
        // init connection object
        String sql       = "SELECT * FROM `customer`";
        String sqlInsert = "INSERT INTO `customer`(`cId`, `firstName`, `lastName`) VALUES ("+ cntCId + ", 'Jim', 'Smith')";
        String sqlUpdate = "UPDATE `customer` SET `cId`='5',`firstName`='Joe',`lastName`='Wright' WHERE `cId`='1'";
        String sqlDelete = "DELETE FROM `customer` WHERE `cId` = '2'";

        String[] strRslt = new String[3];
        cntCId++;
        mysqlConnect.connect();

        try {

            sql = "SELECT * FROM `customer`";
            mysqlConnect.readTable(sql);
            
            
//            strRslt = mysqlConnect.getResults(count);
//            //System.out.println("Results: " + strRslt[2] + ", " + strRslt[1]);
//            count++;
//            MySQLGui_results rsltGui = new MySQLGui_results();
//            rsltGui.setResults(strRslt, count);
    
    
        } catch (SQLException ex) {
            System.out.println("Reading Data Error..." + sql);
            
        }

        mysqlConnect.disconnect();

        
          mysqlConnect.connect();

        try {

            mysqlConnect.insertTable(sqlInsert);

      
        } catch (SQLException ex) {
            System.out.println("Inserting Data Error..." + sqlInsert);
        }

        mysqlConnect.disconnect();
        
        
          mysqlConnect.connect();

        try {

      
            mysqlConnect.updateTable(sqlUpdate);
     
        } catch (SQLException ex) {
             System.out.println("Updating Data Error..." + sqlUpdate);
        }

        mysqlConnect.disconnect();
        
        
        
          mysqlConnect.connect();

        try {
          
             mysqlConnect.deleteTable(sqlDelete);

        } catch (SQLException ex) {
             System.out.println("Deleting Data Error..." + sqlDelete);
        }

        mysqlConnect.disconnect();
        
        
        
//        mysqlConnect.connect();
//
//        try {
//            mysqlConnect.readTableViaPS(sql);
//        } catch (SQLException ex) {
//            Logger.getLogger(MySQLGui_basic.class.getName()).log(Level.SEVERE, null, ex);
//        }
//
//        mysqlConnect.disconnect();
    }

    /**
     * MouseMotionEvent handlers
     *
     * @param evt
     */
    // Called back when the mouse-pointer has been moved
    @Override
    public void mouseMoved(MouseEvent evt) {
        tfMousePositionX.setText(evt.getX() + "");
        tfMousePositionY.setText(evt.getY() + "");
    }

    // Not Used, but need to provide an empty body for compilation
    @Override
    public void mouseDragged(MouseEvent evt) {
    }

    // Not used - need to provide an empty body to compile.
    @Override
    public void mousePressed(MouseEvent evt) {
    }

    @Override
    public void mouseReleased(MouseEvent evt) {
    }

    @Override
    public void mouseEntered(MouseEvent evt) {
    }

    @Override
    public void mouseExited(MouseEvent evt) {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        tfMouseX.setText(e.getX() + "");
        tfMouseY.setText(e.getY() + "");
    }

    /**
     * KeyEvent handlers
     */
    // Called back when a key has been typed (pressed and released)
    @Override
    public void keyTyped(KeyEvent evt) {
        taDisplay.append("You typed " + evt.getKeyChar() + "\n");
        keyEnter = keyEnter + evt.getKeyChar();
    }

    // Not Used, but need to provide an empty body for compilation
    @Override
    public void keyPressed(KeyEvent evt) {
        
    }

    @Override
    public void keyReleased(KeyEvent evt) {
        String stars = "*";
        for(int i =0; i< pwCnt;i++){
        stars = stars + "*";  
        }
        tfPassword.setText(stars); // Convert int to String
        pwCnt++;
    }

    /**
     * BtnListener is a named inner class used as ActionEvent listener for all
     * the Buttons.
     */
    private class BtnListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent evt) {
            // Need to determine which button fired the event.
            // the getActionCommand() returns the Button's label
//            String btnLabel = evt.getActionCommand();
//            if (btnLabel.equals("Count Up")) {
//                ++count;
//            } else if (btnLabel.equals("Count Down")) {
//                --count;
//            } else {
//                count = 0;
//            }
//            tfCount.setText(count + "");
            // Need to determine which button has fired the event.
            Button source = (Button) evt.getSource();
            // Get a reference of the source that has fired the event.
            // getSource() returns a java.lang.Object. Downcast back to Button.
            if (source == btnCountUp) {
                ++count;
            } else if (source == btnCountDown) {
                --count;
            } else {
                //count = 0;
                keyEnter = "";
                pwCnt = 0;
    
            }
            tfCount.setText(count + "");
        }
    }
}
