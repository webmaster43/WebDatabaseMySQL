/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webdatabase;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author Student
 */
 public class MyGui_SwingCounter extends JFrame {

    private JTextField tfCount;  // Use Swing's JTextField instead of AWT's TextField
    private JButton btnCount;    // Using Swing's JButton instead of AWT's Button
    private int count = 0;

    // Constructor to setup the GUI components and event handlers
    public MyGui_SwingCounter() {
        // Retrieve the content-pane of the top-level container JFrame
        // All operations done on the content-pane
        Container cp = getContentPane();
        cp.setLayout(new FlowLayout());   // The content-pane sets its layout

        cp.add(new JLabel("Counter"));
        tfCount = new JTextField("0");
        tfCount.setEditable(false);
        cp.add(tfCount);

        btnCount = new JButton("Count");
        cp.add(btnCount);

        // Allocate an anonymous instance of an anonymous inner class that
        //  implements ActionListener as ActionEvent listener
        btnCount.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                ++count;
                tfCount.setText(count + "");
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  // Exit program if close-window button clicked
        setTitle("Swing Counter"); // "super" JFrame sets title
        setSize(300, 100);         // "super" JFrame sets initial size
        setLocation(0, 0);
        setVisible(true);          // "super" JFrame shows
    }

    
}
