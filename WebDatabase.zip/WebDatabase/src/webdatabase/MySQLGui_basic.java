/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webdatabase;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

/**
 *
 * @author Student
 */
// An MySQL program inherits from the top-level container java.awt.Frame
public class MySQLGui_basic extends Frame implements ActionListener {

    private Label lblUsername;    // Declare a Label component 
    private TextField tfUsername; // Declare a TextField component 
    private Label lblPassword;    // Declare a Label component 
    private TextField tfPassword; // Declare a TextField component 
    private Button btnEnter;   // Declare a Button component
    private String username = "";     // Counter's value
    private String password = "";     // Counter's value

    // Constructor to setup GUI components and event handlers
    public MySQLGui_basic() {

        JFrame frame = new JFrame();
        frame.setSize(400, 120);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
        frame.setLayout(new FlowLayout());
        // "super" Frame, which is a Container, sets its layout to FlowLayout to arrange
        // the components from left-to-right, and flow to next row from top-to-bottom.

        lblUsername = new Label("Username");  // construct the Label component
        frame.add(lblUsername);                    // "super" Frame container adds Label component

        tfUsername = new TextField(username, 30); // construct the TextField component with initial text
        tfUsername.setEditable(true);       // set to read-only
             
        frame.add(tfUsername);                     // "super" Frame container adds TextField component

        lblPassword = new Label("Password");  // construct the Label component
        frame.add(lblPassword);                    // "super" Frame container adds Label component

        tfPassword = new TextField(password, 23); // construct the TextField component with initial text
        tfPassword.setEditable(true);       // set to read-only
             
        frame.add(tfPassword);                     // "super" Frame container adds TextField component

        btnEnter = new Button("Enter");   // construct the Button component
        frame.add(btnEnter);                    // "super" Frame container adds Button component


        btnEnter.addActionListener(this);
        // "btnCount" is the source object that fires an ActionEvent when clicked.
        // The source add "this" instance as an ActionEvent listener, which provides
        //   an ActionEvent handler called actionPerformed().
        // Clicking "btnCount" invokes actionPerformed().

        frame.setTitle("MySQL Password");  // "super" Frame sets its title
      
        // For inspecting the Container/Components objects
        // System.out.println(this);
        // System.out.println(lblCount);
        // System.out.println(tfCount);
        // System.out.println(btnCount);
        frame.setLocation(0, 120);
        frame.setVisible(true);         // "super" Frame shows

        // System.out.println(this);
        // System.out.println(lblCount);
        // System.out.println(tfCount);
        // System.out.println(btnCount);
    }
    
    
    public String getUsername(){
    
    return username;
    }
    
    public String getPassword(){
    
    return password;
    }
    
    
    
    // ActionEvent handler - Called back upon button-click.
    @Override
    public void actionPerformed(ActionEvent evt) {
        username = tfUsername.getText(); // Convert int to String 
        // Display the counter value on the TextField tfCount
        tfUsername.setText("**********"); // Convert int to String
        
        password = tfPassword.getText(); // Convert int to String 
        // Display the counter value on the TextField tfCount
        tfPassword.setText("**********"); // Convert int to String
        
        // !_ note _! this is just init
        // it will not create a connection
        MysqlConnect mysqlConnect = new MysqlConnect(username, password);
        // init connection object
        String sql = "SELECT * FROM `customer`";

        mysqlConnect.connect();

        try {
            mysqlConnect.readTable(sql);
        } catch (SQLException ex) {
            Logger.getLogger(MySQLGui_testbed.class.getName()).log(Level.SEVERE, null, ex);
        }

        mysqlConnect.disconnect();

        mysqlConnect.connect();

        try {
            mysqlConnect.readTableViaPS(sql);
        } catch (SQLException ex) {
            Logger.getLogger(MySQLGui_testbed.class.getName()).log(Level.SEVERE, null, ex);
        }

        mysqlConnect.disconnect();
    }

}
